from . import dummy

from dummy import calc

__version__ = '0.0.4'