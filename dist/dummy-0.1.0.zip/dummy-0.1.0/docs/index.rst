.. dummy documentation master file, created by
   sphinx-quickstart on Mon Mar 31 16:51:25 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to dummy's documentation!
=================================

.. image:: Dummy_icon.png
	:height: 100px
	:alt: logo
	:align: center

.. include:: README.txt


Contents:
---------

.. toctree::
   :maxdepth: 4

   dummy


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

