dummy Package
=============

:mod:`dummy` Package
--------------------

.. automodule:: dummy.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dummy` Module
-------------------

.. automodule:: dummy.dummy
    :members:
    :undoc-members:
    :show-inheritance:

