#! /usr/bin/env python
#
# \Dropbox\Reasearch_Nguyen\Dummy\dummy\
# Hoang Long Nguyen (hn269@cornell.edu)
# 2014/04/04

def sub(n1,n2):
    result = 0
    result = n1-n2
    return result