#! /usr/bin/env python
#
# \Dropbox\Reasearch_Nguyen\Dummy\dummy\
# Hoang Long Nguyen (hn269@cornell.edu)
# 2014/03/28

def mul(n1,n2):
    result = n1*n2
    return result